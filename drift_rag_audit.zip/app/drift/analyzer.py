
from app.drift.report import DriftChange, DriftReport
from app.drift.semantic import SemanticDrift


class DriftAnalyzer:
    """
    Compares retrieval results across document versions.

    Chunk indices are version-local, so chunks are matched
    using semantic similarity rather than their indices.
    """

    MATCH_THRESHOLD = 0.72

    def __init__(self, semantic_detector: SemanticDrift):
        self.semantic_detector = semantic_detector

    def analyze(self, query, v1_results, v2_results) -> DriftReport:
        # Each result has the form: (chunk, retrieval_score)
        v1_chunks = [chunk for chunk, _ in v1_results]
        v2_chunks = [chunk for chunk, _ in v2_results]

        # Build all cross-version semantic similarities.
        candidates = []

        for i, chunk1 in enumerate(v1_chunks):
            for j, chunk2 in enumerate(v2_chunks):
                distance = self.semantic_detector.calculate(
                    chunk1.text, chunk2.text
                )
                similarity = 1.0 - distance

                if similarity >= self.MATCH_THRESHOLD:
                    candidates.append((similarity, i, j, distance))

        # Greedily create one-to-one matches, best similarity first.
        candidates.sort(key=lambda item: item[0], reverse=True)

        matched_v1 = set()
        matched_v2 = set()
        matches = []

        for similarity, i, j, distance in candidates:
            if i in matched_v1 or j in matched_v2:
                continue

            matched_v1.add(i)
            matched_v2.add(j)
            matches.append((i, j, distance))

        # Retrieval overlap reflects semantically corresponding chunks.
        denominator = max(len(v1_chunks), len(v2_chunks))
        retrieval_overlap = (
            len(matches) / denominator if denominator else 1.0
        )

        # Rank change compares the positions of matched chunks.
        if matches:
            max_rank = max(len(v1_chunks), len(v2_chunks), 1)
            rank_change = sum(
                abs(i - j) / max_rank for i, j, _ in matches
            ) / len(matches)
        else:
            rank_change = 0.0

        changes = []
        weighted_changes = []
        total_weight = 0.0

        # Report matched content and its semantic change.
        for i, j, distance in matches:
            chunk1 = v1_chunks[i]
            chunk2 = v2_chunks[j]

            # Earlier-ranked results contribute more.
            weight = 1.0 / (i + 1)
            weighted_changes.append(distance * weight)
            total_weight += weight

            if distance > 0.05:
                changes.append(
                    DriftChange(
                        chunk_index=chunk1.chunk_index,
                        v1_text=chunk1.text,
                        v2_text=chunk2.text,
                        change_type="CONTENT",
                    )
                )

        # Chunks without a semantic counterpart are additions/removals.
        for i, chunk in enumerate(v1_chunks):
            if i not in matched_v1:
                changes.append(
                    DriftChange(
                        chunk_index=chunk.chunk_index,
                        v1_text=chunk.text,
                        v2_text="",
                        change_type="REMOVED",
                    )
                )

        for j, chunk in enumerate(v2_chunks):
            if j not in matched_v2:
                changes.append(
                    DriftChange(
                        chunk_index=chunk.chunk_index,
                        v1_text="",
                        v2_text=chunk.text,
                        change_type="ADDED",
                    )
                )

        # No matched chunks means content change cannot be measured
        # between corresponding chunks; retrieval drift captures the
        # lack of overlap instead of automatically reporting 100%.
        semantic_change = (
            sum(weighted_changes) / total_weight
            if total_weight
            else 0.0
        )

        return DriftReport(
            query=query,
            retrieval_overlap=retrieval_overlap,
            rank_change=rank_change,
            semantic_change=max(0.0, semantic_change),
            changes=changes,
        )
